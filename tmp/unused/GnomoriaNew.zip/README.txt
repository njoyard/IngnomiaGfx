Use/edit whatever you like, some of these assets date back to 2011 so they may be out of date and/or require additional formatting. 

Let me know if you have any questions.

-Rhopunzel